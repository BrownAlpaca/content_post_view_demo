                   <?php
                        function getWebsiteName() {
                        	$name="mindfeed";
                            return $name;
                        }
                    ?> 