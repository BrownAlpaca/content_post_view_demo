<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">

		
        <!--Create a title of the page-->
        <title><?php echo $pageTitle ?></title>
        <?php include "db.php";?>
    </head>
    <body>
    		<header>
                <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                    <h3 class="text-light">
                    <a class="nav-link text-light" href="index.php" >
				    <?php include "includes/functions.php";
                        echo getWebsiteName();?>  
                     </a>
                    </h3>
                    <h4 class="text-light"><a class="nav-link text-light" href="theforce.php" >the force</a></h4></nav></header>              
                                     
                                  	
    				
    		    